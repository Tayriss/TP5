package com.leo.recyclerview;

import android.view.View;

public interface DetecteurDeClicSurRecycler {
    public void clicSurRecyclerItem(int position, View v);
}
